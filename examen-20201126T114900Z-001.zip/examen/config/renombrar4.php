<?php 
    namespace config;
	
    class Autoload {
        
        public static function Start() {
            spl_autoload_register(function($className)
			{
                $classPath = strtolower(str_replace("\\", "/", ROOT.$className).".class.php");
                
				include_once($classPath);
			});
        }
    }
?>