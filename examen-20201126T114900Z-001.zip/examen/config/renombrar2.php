<?php

define("ROOT", dirname(__DIR__) . "/");
define("VIEWS", ROOT . 'views/');

define("FRONT_ROOT", "/recu-com-2/");
define("ASSETS", FRONT_ROOT . 'assets/');






